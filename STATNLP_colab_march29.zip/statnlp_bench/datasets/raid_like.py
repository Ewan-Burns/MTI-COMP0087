# RAID-like dataset loader for generative-detection track.
#
# RAID format: each row has a source_id, a model name, and a generation.
# Rows where model=="human" provide the human reference text; other rows
# provide the prompt. We pair them by source_id to produce (prompt, human_text)
# pairs. Rows with attack != "none" are adversarial perturbations and are skipped.
#
# For non-RAID datasets, a generic fallback reads prompt_field / human_field directly.

from __future__ import annotations

from pathlib import Path
from typing import Any

from ..hf_cache import load_dataset_local_first
from ..progress import progress_iter
from ..registry import register_dataset
from ..types import DatasetManifest, DatasetSpec
from ._common import assign_splits, save_dataset, try_load_cached


# Detect RAID-format datasets by checking for the expected column schema
def _looks_like_raid(dataset: Any) -> bool:
    columns = set(getattr(dataset, "column_names", []) or [])
    return {"id", "source_id", "model", "generation", "prompt"}.issubset(columns)


def _extract_raid_pair(item: dict, repo_id: str, prompt_field: str) -> tuple[str, dict | None]:
    source_id = str(item.get("source_id") or item.get("id") or "").strip()
    if not source_id:
        return "", None

    # Skip adversarially-attacked rows — we only want clean generations
    attack = str(item.get("attack", "none") or "none").strip().lower()
    if attack not in {"", "none"}:
        return source_id, None

    model_name = str(item.get("model", "") or "").strip().lower()
    category = str(item.get("domain", "raid")).strip() or "raid"
    meta = {
        "source_dataset": repo_id,
        "source_id": source_id,
        "title": item.get("title"),
        "domain": item.get("domain"),
    }

    # "human" rows carry the ground-truth text; all other rows carry the prompt
    if model_name == "human":
        text = str(item.get("generation", "") or "").strip()
        if text:
            return source_id, {"type": "human", "reference_text": text, "category": category, "metadata": meta}
    else:
        text = str(item.get(prompt_field, "") or "").strip()
        if text:
            return source_id, {"type": "prompt", "prompt_text": text, "category": category, "metadata": meta}

    return source_id, None


def _prepare_raid_rows(
    dataset: Any, *, repo_id: str, prompt_field: str,
    max_items: int | None, seed: int, train_ratio: float, val_ratio: float,
) -> list[dict[str, Any]]:
    if max_items is not None:
        dataset = dataset.shuffle(seed=seed)

    # Accumulate prompt and human rows separately, then join by source_id.
    # Once both sides of a pair are seen, emit the combined row immediately.
    prompts: dict[str, dict] = {}
    humans: dict[str, dict] = {}
    paired: set[str] = set()
    rows: list[dict[str, Any]] = []

    for item in progress_iter(dataset, desc="raid rows", total=len(dataset), unit="row", leave=False):
        source_id, info = _extract_raid_pair(item, repo_id, prompt_field)
        if not source_id or source_id in paired or info is None:
            continue

        if info["type"] == "human":
            humans[source_id] = info
        else:
            prompts[source_id] = info

        if source_id not in prompts or source_id not in humans:
            continue

        # Both sides found — merge into one output row and free memory
        p, h = prompts.pop(source_id), humans.pop(source_id)
        paired.add(source_id)
        rows.append({
            "prompt_id": source_id,
            "prompt_text": p["prompt_text"],
            "category": p.get("category") or h.get("category", "raid"),
            "reference_text": h["reference_text"],
            "split": "train",
            "metadata": {**h.get("metadata", {}), **p.get("metadata", {}), "source_dataset": repo_id},
        })
        if max_items is not None and len(rows) >= max_items:
            break

    return assign_splits(rows, seed=seed, train_ratio=train_ratio, val_ratio=val_ratio)


# Fallback for non-RAID datasets: reads prompt and human text from named columns directly
def _prepare_generic_rows(
    dataset: Any, *, repo_id: str, dataset_name: str,
    prompt_field: str, human_field: str,
    prompt_id_field: str | None, category_field: str | None,
    seed: int, train_ratio: float, val_ratio: float,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for idx, item in enumerate(progress_iter(dataset, desc=f"{dataset_name} rows", total=len(dataset), unit="row", leave=False)):
        prompt_text = str(item.get(prompt_field, "")).strip()
        human_text = str(item.get(human_field, "")).strip()
        if not prompt_text or not human_text:
            continue
        rows.append({
            "prompt_id": str(item.get(prompt_id_field) if prompt_id_field else idx),
            "prompt_text": prompt_text,
            "category": str(item.get(category_field, "external")) if category_field else "external",
            "reference_text": human_text,
            "split": "train",
            "metadata": {"source_dataset": repo_id},
        })
    return assign_splits(rows, seed=seed, train_ratio=train_ratio, val_ratio=val_ratio)


def prepare_raid_like_dataset(
    *,
    output_dir: str | Path,
    dataset_name: str = "raid_like",
    repo_id: str,
    config_name: str | None = None,
    revision: str | None = None,
    split: str = "train",
    prompt_field: str = "prompt",
    human_field: str = "human_text",
    prompt_id_field: str | None = None,
    category_field: str | None = None,
    max_items: int | None = None,
    seed: int = 47,
    train_ratio: float = 0.5,
    val_ratio: float = 0.1,
) -> DatasetManifest:
    root_dir = Path(output_dir).expanduser().resolve()
    records_path = root_dir / "prompts.jsonl"
    manifest_path = root_dir / "manifest.json"
    expected_metadata = {
        "name": dataset_name, "repo_id": repo_id, "config_name": config_name,
        "revision": revision, "split": split, "prompt_field": prompt_field,
        "human_field": human_field, "prompt_id_field": prompt_id_field,
        "category_field": category_field, "max_items": max_items,
        "seed": seed, "train_ratio": train_ratio, "val_ratio": val_ratio,
    }

    cached = try_load_cached(
        manifest_path, records_path, expected_metadata,
        dataset_name=dataset_name, track="generative_detection",
        external=True, root_dir=root_dir, cache_label="external detection dataset",
    )
    if cached:
        return cached

    dataset = load_dataset_local_first(repo_id, config_name, revision=revision, split=split)

    # Auto-detect whether this is true RAID format or a simpler prompt/human schema
    if _looks_like_raid(dataset):
        rows = _prepare_raid_rows(
            dataset, repo_id=repo_id, prompt_field=prompt_field,
            max_items=max_items, seed=seed, train_ratio=train_ratio, val_ratio=val_ratio,
        )
    else:
        if max_items is not None and len(dataset) > max_items:
            dataset = dataset.shuffle(seed=seed).select(range(max_items))
        rows = _prepare_generic_rows(
            dataset, repo_id=repo_id, dataset_name=dataset_name,
            prompt_field=prompt_field, human_field=human_field,
            prompt_id_field=prompt_id_field, category_field=category_field,
            seed=seed, train_ratio=train_ratio, val_ratio=val_ratio,
        )

    return save_dataset(
        rows, records_path=records_path, manifest_path=manifest_path,
        root_dir=root_dir, dataset_name=dataset_name,
        track="generative_detection", external=True,
        expected_metadata=expected_metadata,
        extra_metadata={"num_prompts": len(rows), "num_reference_prompts": len(rows)},
    )


register_dataset(
    DatasetSpec(
        name="raid_like",
        track="generative_detection",
        external=True,
        prepare=prepare_raid_like_dataset,
    )
)
