# NLU task datasets for the task-efficiency track.
#
# Each dataset is a standard NLU benchmark (sentiment, NLI, QA, topic classification)
# normalized into a common TaskExample schema with text_a, optional text_b, and a label.
# The task-efficiency track measures how well systems perform these tasks under
# constrained compute budgets.

from __future__ import annotations

from collections import Counter
from pathlib import Path

from ..hf_cache import load_dataset_local_first
from ..progress import progress_iter
from ..registry import register_dataset
from ..types import DatasetManifest, DatasetSpec, TaskExample
from ._common import save_dataset, try_load_cached


# --- Per-dataset normalizers ---
# Each converts a raw HuggingFace example dict into our unified TaskExample format.

def _normalize_glue_sst2(example: dict, idx: int, split: str) -> TaskExample:
    label = int(example["label"])
    return TaskExample(
        example_id=f"SST2-{split}-{idx}", dataset="SST2", split=split,
        label=label, text_a=str(example["sentence"]),
        label_text="positive" if label == 1 else "negative",
    )


def _normalize_mnli(example: dict, idx: int, split: str) -> TaskExample:
    labels = {0: "entailment", 1: "neutral", 2: "contradiction"}
    label = int(example["label"])
    return TaskExample(
        example_id=f"MNLI-{split}-{idx}", dataset="MNLI", split=split,
        label=label, text_a=str(example["premise"]),
        text_b=str(example["hypothesis"]), label_text=labels.get(label),
    )


def _normalize_boolq(example: dict, idx: int, split: str) -> TaskExample:
    # BoolQ labels come as booleans, ints, or strings depending on the HF version
    raw_label = example.get("label", example.get("answer"))
    if raw_label is None:
        raise KeyError("BoolQ example is missing both 'label' and 'answer' fields")
    if isinstance(raw_label, str):
        normalized = raw_label.strip().lower()
        if normalized in {"1", "true", "yes"}:
            label = 1
        elif normalized in {"0", "false", "no"}:
            label = 0
        else:
            raise ValueError(f"Unsupported BoolQ label value: {raw_label!r}")
    else:
        label = int(raw_label)
    return TaskExample(
        example_id=f"BoolQ-{split}-{idx}", dataset="BoolQ", split=split,
        label=label, text_a=str(example["question"]),
        text_b=str(example["passage"]), label_text="true" if label == 1 else "false",
    )


def _normalize_agnews(example: dict, idx: int, split: str) -> TaskExample:
    labels = {0: "world", 1: "sports", 2: "business", 3: "science_tech"}
    label = int(example["label"])
    return TaskExample(
        example_id=f"AGNews-{split}-{idx}", dataset="AGNews", split=split,
        label=label, text_a=str(example["text"]), label_text=labels.get(label),
    )


# Registry: (hf_repo, hf_config, logical-to-actual split mapping, normalizer).
# Split mapping is needed because some datasets lack a true test set, so we
# re-use validation splits (e.g., SST2 test -> validation, MNLI test -> validation_mismatched).
DATASET_LOADERS = {
    "SST2": ("glue", "sst2", {"validation": "validation", "train": "train", "test": "validation"}, _normalize_glue_sst2),
    "MNLI": ("glue", "mnli", {"validation": "validation_matched", "train": "train", "test": "validation_mismatched"}, _normalize_mnli),
    "BoolQ": ("super_glue", "boolq", {"validation": "validation", "train": "train", "test": "validation"}, _normalize_boolq),
    "AGNews": ("ag_news", None, {"validation": "test", "train": "train", "test": "test"}, _normalize_agnews),
}


def _example_to_row(ex: TaskExample) -> dict:
    return {
        "example_id": ex.example_id, "dataset": ex.dataset, "split": ex.split,
        "label": ex.label, "text_a": ex.text_a, "text_b": ex.text_b,
        "label_text": ex.label_text, "metadata": ex.metadata,
    }


def prepare_nlu_dataset(
    *,
    dataset_name: str,
    output_dir: str | Path,
    max_train_items: int | None = None,
    max_eval_items: int | None = None,
    seed: int = 42,
) -> DatasetManifest:
    repo_id, config_name, split_map, normalizer = DATASET_LOADERS[dataset_name]
    root_dir = Path(output_dir).expanduser().resolve()
    records_path = root_dir / "examples.jsonl"
    manifest_path = root_dir / "manifest.json"
    expected_metadata = {
        "name": dataset_name, "repo_id": repo_id, "config_name": config_name,
        "max_train_items": max_train_items, "max_eval_items": max_eval_items,
        "seed": seed, "split_map": split_map,
    }

    cached = try_load_cached(
        manifest_path, records_path, expected_metadata,
        dataset_name=dataset_name, track="task_efficiency",
        external=True, root_dir=root_dir, cache_label=f"task dataset {dataset_name}",
    )
    if cached:
        return cached

    # Load each logical split (train/val/test), mapping to the actual HF split name
    rows: list[dict] = []
    for logical_split, actual_split in split_map.items():
        dataset = load_dataset_local_first(repo_id, config_name, split=actual_split)
        max_items = max_train_items if logical_split == "train" else max_eval_items
        if max_items is not None and len(dataset) > max_items:
            dataset = dataset.shuffle(seed=seed).select(range(max_items))
        for idx, item in enumerate(progress_iter(
            dataset, desc=f"{dataset_name} {logical_split}",
            total=len(dataset), unit="row", leave=False,
        )):
            rows.append(_example_to_row(normalizer(item, idx, logical_split)))

    return save_dataset(
        rows, records_path=records_path, manifest_path=manifest_path,
        root_dir=root_dir, dataset_name=dataset_name,
        track="task_efficiency", external=True,
        expected_metadata=expected_metadata,
        extra_metadata={
            "num_rows": len(rows),
            "split_counts": dict(Counter(row["split"] for row in rows)),
        },
    )


# Auto-register all four NLU datasets with the benchmark registry
for dataset_name in DATASET_LOADERS:
    register_dataset(
        DatasetSpec(
            name=dataset_name,
            track="task_efficiency",
            external=True,
            prepare=prepare_nlu_dataset,
        )
    )
