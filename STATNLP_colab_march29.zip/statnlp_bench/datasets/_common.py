# Shared dataset utilities: caching, train/val/test splitting, and persistence.
# Every dataset loader (mt_bench, raid_like, etc.) delegates to these helpers
# so that caching and split logic stays consistent across the benchmark.

from __future__ import annotations

import random
from pathlib import Path
from typing import Any

from ..progress import progress_write
from ..results import read_json, write_json, write_jsonl
from ..types import DatasetManifest


# --- Path helpers ---

def artifact_root(root_dir: Path) -> str:
    # Walk up to the grandparent-of-grandparent to find the top-level artifact dir
    return str(root_dir.parents[2]) if len(root_dir.parents) >= 3 else str(root_dir.parent)


# --- Deterministic train/val/test splitting ---

def assign_splits(
    rows: list[dict[str, Any]],
    *,
    seed: int,
    train_ratio: float = 0.5,
    val_ratio: float = 0.1,
) -> list[dict[str, Any]]:
    # Use a dedicated Random instance so we never disturb global RNG state
    shuffled = list(rows)
    random.Random(seed).shuffle(shuffled)
    n = len(shuffled)
    train_end = int(n * train_ratio)
    val_end = train_end + int(n * val_ratio)
    for idx, row in enumerate(shuffled):
        if idx < train_end:
            row["split"] = "train"
        elif idx < val_end:
            row["split"] = "validation"
        else:
            row["split"] = "test"
    return shuffled


# --- Cache-aware loading and saving ---
# Datasets are cached as a manifest.json (metadata for invalidation) plus a
# records JSONL file. If metadata matches exactly, the cached version is reused.

def try_load_cached(
    manifest_path: Path,
    records_path: Path,
    expected_metadata: dict[str, Any],
    *,
    dataset_name: str,
    track: str,
    external: bool,
    root_dir: Path,
    cache_label: str,
) -> DatasetManifest | None:
    if not (records_path.exists() and manifest_path.exists()):
        return None
    cached = read_json(manifest_path)
    # Any metadata mismatch (changed seed, ratios, source file, etc.) invalidates cache
    if not all(cached.get(k) == v for k, v in expected_metadata.items()):
        return None
    progress_write(f"Reusing cached {cache_label} at {root_dir}")
    return DatasetManifest(
        name=dataset_name, track=track, external=external,
        root_dir=root_dir, records_path=records_path, metadata=cached,
    )


def save_dataset(
    rows: list[dict[str, Any]],
    *,
    records_path: Path,
    manifest_path: Path,
    root_dir: Path,
    dataset_name: str,
    track: str,
    external: bool,
    expected_metadata: dict[str, Any],
    extra_metadata: dict[str, Any] | None = None,
) -> DatasetManifest:
    write_jsonl(records_path, rows)
    metadata = {
        **expected_metadata,
        **(extra_metadata or {}),
        "artifact_root": artifact_root(root_dir),
    }
    write_json(manifest_path, metadata)
    return DatasetManifest(
        name=dataset_name, track=track, external=external,
        root_dir=root_dir, records_path=records_path, metadata=metadata,
    )
