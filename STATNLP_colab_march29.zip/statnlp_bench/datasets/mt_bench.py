# MT-Bench dataset loader for the generative-detection track.
# MT-Bench is a multi-turn question set; we extract only the first turn's prompt
# and any reference answer. The JSONL question file uses either "turns" or "prompt"
# as the key for the list of turn texts.

from __future__ import annotations

import json
from collections import defaultdict
from hashlib import sha256
from pathlib import Path

from ..progress import progress_iter
from ..registry import register_dataset
from ..types import DatasetManifest, DatasetSpec
from ._common import assign_splits, save_dataset, try_load_cached


# Used for cache invalidation — if the source file changes, we re-process
def _file_sha256(path: Path) -> str:
    digest = sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


# Round-robin across categories so that subsampling doesn't over-represent any one topic
def _balance_prompt_entries(entries: list[dict], max_prompts: int) -> list[dict]:
    by_category: dict[str, list[dict]] = defaultdict(list)
    for entry in entries:
        by_category[entry["category"]].append(entry)
    selected: list[dict] = []
    categories = sorted(by_category)
    row = 0
    while len(selected) < max_prompts:
        added = False
        for cat in categories:
            if row < len(by_category[cat]):
                selected.append(by_category[cat][row])
                added = True
                if len(selected) >= max_prompts:
                    break
        if not added:
            break
        row += 1
    return selected


def load_mt_bench_entries(question_file: Path) -> list[dict]:
    with question_file.open("r", encoding="utf-8") as f:
        total_lines = sum(1 for _ in f)
    entries: list[dict] = []
    with question_file.open("r", encoding="utf-8") as f:
        for raw_line in progress_iter(f, desc="MT-Bench prompts", total=total_lines, unit="line", leave=False):
            line = raw_line.strip()
            if not line:
                continue
            payload = json.loads(line)
            # MT-Bench stores turn prompts under "turns" or "prompt"; we only use the first turn
            prompts = payload.get("turns") or payload.get("prompt") or []
            if not prompts:
                continue
            prompt_text = str(prompts[0]).strip()
            if not prompt_text:
                continue
            # Reference answers are optional; grab the first non-empty one if present
            reference = payload.get("reference") or []
            reference_text = next((str(r).strip() for r in reference if str(r).strip()), "")
            entries.append({
                "prompt_id": str(payload.get("question_id", len(entries) + 1)),
                "category": str(payload.get("category", "unknown")).strip() or "unknown",
                "prompt_text": prompt_text,
                "reference_text": reference_text,
                "metadata": {
                    "question_id": payload.get("question_id"),
                    "raw_reference": reference,
                },
            })
    return entries


def prepare_mt_bench_dataset(
    *,
    question_file: str | Path,
    output_dir: str | Path,
    dataset_name: str = "mt_bench_local",
    split_seed: int = 47,
    train_ratio: float = 0.5,
    val_ratio: float = 0.1,
    max_prompts: int | None = None,
    balance_categories: bool = True,
) -> DatasetManifest:
    question_path = Path(question_file).expanduser().resolve()
    root_dir = Path(output_dir).expanduser().resolve()
    records_path = root_dir / "prompts.jsonl"
    manifest_path = root_dir / "manifest.json"

    expected_metadata = {
        "name": dataset_name,
        "question_file": str(question_path),
        "question_file_sha256": _file_sha256(question_path),
        "split_seed": split_seed,
        "train_ratio": train_ratio,
        "val_ratio": val_ratio,
        "test_ratio": 1.0 - train_ratio - val_ratio,
        "max_prompts": max_prompts,
        "balance_categories": balance_categories,
    }

    cached = try_load_cached(
        manifest_path, records_path, expected_metadata,
        dataset_name=dataset_name, track="generative_detection",
        external=False, root_dir=root_dir, cache_label="MT-Bench dataset",
    )
    if cached:
        return cached

    entries = load_mt_bench_entries(question_path)
    if max_prompts is not None and max_prompts < len(entries):
        entries = _balance_prompt_entries(entries, max_prompts) if balance_categories else entries[:max_prompts]

    rows = assign_splits(
        [{**e, "split": "train"} for e in entries],
        seed=split_seed, train_ratio=train_ratio, val_ratio=val_ratio,
    )

    return save_dataset(
        rows, records_path=records_path, manifest_path=manifest_path,
        root_dir=root_dir, dataset_name=dataset_name,
        track="generative_detection", external=False,
        expected_metadata=expected_metadata,
        extra_metadata={
            "num_prompts": len(rows),
            "num_reference_prompts": sum(1 for r in rows if r.get("reference_text")),
        },
    )


register_dataset(
    DatasetSpec(
        name="mt_bench_local",
        track="generative_detection",
        external=False,
        prepare=prepare_mt_bench_dataset,
    )
)
