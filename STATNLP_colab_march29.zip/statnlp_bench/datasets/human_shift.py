# Domain-shift evaluation set for generative detection.
#
# Purpose: test whether a detector trained on one domain (e.g., MT-Bench prompts)
# generalizes to human-written text from a different domain (e.g., news articles).
# All rows are test-only and have no prompt — just human reference text — so they
# can only be used for evaluation, not training.

from __future__ import annotations

from pathlib import Path

from ..hf_cache import load_dataset_local_first
from ..progress import progress_iter
from ..registry import register_dataset
from ..types import DatasetManifest, DatasetSpec
from ._common import save_dataset, try_load_cached


def prepare_human_shift_dataset(
    *,
    output_dir: str | Path,
    dataset_name: str = "cc_news_shift",
    repo_id: str = "cc_news",
    revision: str | None = None,
    split: str = "train",
    text_field: str = "text",
    max_items: int = 500,
    seed: int = 47,
) -> DatasetManifest:
    root_dir = Path(output_dir).expanduser().resolve()
    records_path = root_dir / "prompts.jsonl"
    manifest_path = root_dir / "manifest.json"
    expected_metadata = {
        "name": dataset_name, "repo_id": repo_id, "revision": revision,
        "split": split, "text_field": text_field, "max_items": max_items, "seed": seed,
    }

    cached = try_load_cached(
        manifest_path, records_path, expected_metadata,
        dataset_name=dataset_name, track="generative_detection",
        external=True, root_dir=root_dir, cache_label="human-shift dataset",
    )
    if cached:
        return cached

    dataset = load_dataset_local_first(repo_id, revision=revision, split=split)
    if max_items and len(dataset) > max_items:
        dataset = dataset.shuffle(seed=seed).select(range(max_items))

    rows = []
    for idx, item in enumerate(progress_iter(dataset, desc=f"{dataset_name} rows", total=len(dataset), unit="row", leave=False)):
        text = str(item.get(text_field, "")).strip()
        if text:
            # prompt_text is intentionally empty — these are prompt-free human samples
            rows.append({
                "prompt_id": f"human-shift-{idx}",
                "prompt_text": "",
                "category": "human_shift",
                "reference_text": text,
                "split": "test",  # always test — never used for training
                "metadata": {"source_dataset": repo_id},
            })

    return save_dataset(
        rows, records_path=records_path, manifest_path=manifest_path,
        root_dir=root_dir, dataset_name=dataset_name,
        track="generative_detection", external=True,
        expected_metadata=expected_metadata,
        extra_metadata={"num_rows": len(rows)},
    )


register_dataset(
    DatasetSpec(
        name="cc_news_shift",
        track="generative_detection",
        external=True,
        prepare=prepare_human_shift_dataset,
    )
)
