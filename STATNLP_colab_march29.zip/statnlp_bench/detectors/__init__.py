"""Detector implementations."""
